$call mkdir "RESULTADOS\Otros"

$call gams Input_Data.gms r=COES_MODEL.g00  o=_gams_net_gjo0.lst
$if errorlevel 1 $abort errors in Input_Data.gms
